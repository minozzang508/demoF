import React from 'react';

import macaronLogo from '../../assets/images/macaron.png';



const logo = (props) => (
    <div >
        <img src={macaronLogo} alt="macaronLogo" style={{height:'100px', width:'100px'}}></img>
    </div>
);

export default logo;