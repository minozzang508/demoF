// 개인정보 제공 동의
import React from 'react';


function Providing(){
    return(
        <div>
            개인정보 제공 동의 ㅎㅎ
        </div>
    )
}


export default Providing;