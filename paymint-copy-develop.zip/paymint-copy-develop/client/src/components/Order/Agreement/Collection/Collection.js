// 개인정보 수집 동의 
import React from 'react';


function Collection(){
    return(
        <div>
            개인정보 수집 동의 ㅎㅎ
        </div>
    )
}


export default Collection;